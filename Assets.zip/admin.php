<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
include "conexao.php";

$result = $conn->query("SELECT * FROM psicologos");
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Administrativo</title>
    <link rel="stylesheet" href="styles.css"> <!-- Arquivo CSS opcional -->
</head>
<body>
    <h2>Lista de Psicólogos</h2>
    <a href='logout.php'>Sair</a>
    <a href="cadastro.php">Cadastrar Novo Psicólogo</a>

    <table border="1">
        <tr>
            <th>Nome</th>
            <th>Especialidade</th>
            <th>Ações</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['nome']) ?></td>
                <td><?= htmlspecialchars($row['especialidade']) ?></td>
                <td>
                    <a href="editar.php?id=<?= $row['id'] ?>">Editar</a> | 
                    <a href="excluir.php?id=<?= $row['id'] ?>">Excluir</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
