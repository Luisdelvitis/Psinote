<form method="POST" action="inserir.php">
    <input type="text" name="nome" placeholder="Nome" required>
    <input type="text" name="crp" placeholder="CRP" required>
    <input type="text" name="especialidade" placeholder="Especialidade" required>
    <input type="text" name="abordagem" placeholder="Abordagem" required>
    <textarea name="descricao" placeholder="Descrição" required></textarea>
    <input type="text" name="imagem" placeholder="URL da Imagem" required>
    <button type="submit">Cadastrar</button>
</form>
