<?php
session_start();
if (isset($_SESSION['admin'])) {
    header("Location: admin.php");
    exit();
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST["usuario"];
    $senha = $_POST["senha"];
    
    if ($usuario == "admin" && $senha == "1234") { // Troque por um método seguro depois
        $_SESSION['admin'] = true;
        header("Location: admin.php");
        exit();
    } else {
        echo "Usuário ou senha incorretos!";
    }
}
?>
<form method="POST">
    <input type="text" name="usuario" placeholder="Usuário" required>
    <input type="password" name="senha" placeholder="Senha" required>
    <button type="submit">Entrar</button>
</form>
