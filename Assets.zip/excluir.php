<?php
include 'conexao.php';

$id = $_GET['id'];

$sql = "DELETE FROM psicologos WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo "Psicólogo excluído com sucesso!";
} else {
    echo "Erro: " . $conn->error;
}

$conn->close();
?>
