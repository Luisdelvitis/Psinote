<?php
include('conexao.php'); // Faz a conexão com o banco de dados

$query = "SELECT * FROM psicologos"; // Consulta no banco de dados
$result = mysqli_query($conexao, $query);

$psicologos = array();

while ($row = mysqli_fetch_assoc($result)) {
    $psicologos[] = $row; // Armazena os dados dos psicólogos em um array
}

echo json_encode($psicologos); // Retorna os dados em formato JSON
?>

