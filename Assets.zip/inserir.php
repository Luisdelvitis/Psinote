<?php
include 'conexao.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $crp = $_POST['crp'];
    $especialidade = $_POST['especialidade'];
    $abordagem = $_POST['abordagem'];
    $descricao = $_POST['descricao'];
    $imagem = $_POST['imagem'];

    $sql = "INSERT INTO psicologos (nome, crp, especialidade, abordagem, descricao, imagem) 
            VALUES ('$nome', '$crp', '$especialidade', '$abordagem', '$descricao', '$imagem')";

    if ($conn->query($sql) === TRUE) {
        echo "Novo psicólogo cadastrado com sucesso!";
    } else {
        echo "Erro: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
